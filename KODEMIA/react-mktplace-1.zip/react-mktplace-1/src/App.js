import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css'

import Navbar from './Navbar'

class App extends Component{
  render(){
    return(
      <Navbar />
    )
  }
}

export default App;
