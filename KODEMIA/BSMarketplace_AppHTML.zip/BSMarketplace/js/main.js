$(".nav-item").on("click", (event) =>{
    //event.target
    let linkURL = $(event.target).data("content-url");
    loadContent(linkURL);
})

const loadContent = (contentUrl) => {
    $("#content-wrapper").load(contentUrl , () => {
        alert("Archivo actualizado")
    })
}


